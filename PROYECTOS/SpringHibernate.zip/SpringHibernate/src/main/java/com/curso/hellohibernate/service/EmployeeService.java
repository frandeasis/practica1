package com.curso.hellohibernate.service;

import com.curso.hellohibernate.model.Employee;

public interface EmployeeService {
	void persistEmployee(Employee employee);
    Employee findEmployeeById(Long id);
    void updateEmployee(Employee employee);
    void deleteEmployee(Employee employee);
}
