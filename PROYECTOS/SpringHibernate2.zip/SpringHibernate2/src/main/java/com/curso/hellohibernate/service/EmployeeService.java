package com.curso.hellohibernate.service;

import com.curso.hellohibernate.model.Department;
import com.curso.hellohibernate.model.Employee;
import com.curso.hellohibernate.model.Organizacion;

public interface EmployeeService {
	
	void persistOrganizacion(Organizacion organizacion);
	void persistEmployee(Employee employee);
	void persistDepartment(Department department);
	
	void updateDepartment(Department department);
	void updateOrganizacion(Organizacion organizacion);
	
    Employee findEmployeeById(Long id);
    void updateEmployee(Employee employee);
    void deleteEmployee(Employee employee);
}
